/*
Author: 	Swarnim	
Roll No.: 	MT2023029
Date: 		15/10/2023
*/

void welcome_screen(){
	system("clear");
	printf("Developed by Swarnim (MT2023029) \n\n\n");
	printf("\nWelcome to Academia\n");
	sleep(1);
	printf("Connecting to server\n");
	sleep(1);
	sleep(1);
	system("clear");
}
