# This script create essential database files required for our system 

#Linux rm -rf command deletes directory forcefully
rm -rf database
mkdir database
mkdir database/accounts
touch database/students
touch database/faculties
touch database/admin
touch database/courses
touch database/accounts/student
touch database/accounts/admin
touch database/accounts/faculty



